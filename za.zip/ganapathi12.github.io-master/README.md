# ganapathi12.github.io

My Portfolio Website

## Setting up development environment

- Clone : `git clone https://github.com/ganapathi12/ganapathi12.github.io.git`
- Install all dependencies : `npm i`
- Run the app : open `index.html`

[![Deploy to DO](https://mp-assets1.sfo2.digitaloceanspaces.com/deploy-to-do/do-btn-blue.svg)](https://cloud.digitalocean.com/apps/new?repo=https://github.com/ganapathi12/ganapathi12.github.io/tree/main)

### Screenshots

![Home Page](images/Capture.JPG)
